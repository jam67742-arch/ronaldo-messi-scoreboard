RONALDO VS MESSI ANDROID PROJECT

This is an Android Studio project (not a compiled APK).

To build the APK:
1. Install Android Studio on a computer.
2. Extract this ZIP file.
3. Open the extracted RonaldoMessiAndroidProject folder in Android Studio.
4. Allow Gradle sync and install the Android SDK Platform 35 if prompted.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will create the APK under:
   app/build/outputs/apk/debug/app-debug.apk

The app runs locally and does not need internet permission.
